// Use this file to store all of the private credentials 
// and connection details

#define SECRET_SSID "RedAlejandro1"		// replace MySSID with your WiFi network name
#define SECRET_PASS ""	// replace MyPassword with your WiFi password

#define SECRET_CH_ID_WEATHER_STATION 1950130	          	//MathWorks weather station​
#define SECRET_READ_APIKEY_COUNTER "UJ25J0M7F16N3QC9"
